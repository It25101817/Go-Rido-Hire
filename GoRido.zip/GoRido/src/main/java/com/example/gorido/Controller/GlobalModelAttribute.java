package com.example.gorido.Controller;

import com.example.gorido.Model.Admin;
import com.example.gorido.Model.Driver;
import com.example.gorido.Model.User;
import com.example.gorido.Repository.AdminRepository;
import com.example.gorido.Repository.DriverRepository;
import com.example.gorido.Repository.UserRepository;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ModelAttribute;

@ControllerAdvice
public class GlobalModelAttribute {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private DriverRepository driverRepository;

    @Autowired
    private AdminRepository adminRepository;

    @ModelAttribute
    public void addGlobalAttributes(Model model, HttpSession session) {

        String userEmail = (String) session.getAttribute("userEmail");
        String adminEmail = (String) session.getAttribute("adminEmail");

        if (userEmail != null) {

            User user = userRepository.findByEmail(userEmail).orElse(null);

            if (user != null) {
                Driver driver = driverRepository.findByUserId(user).orElse(null);

                model.addAttribute("user", user);
                model.addAttribute("driver", driver);
                model.addAttribute("userRole", "USER");
            }
        }

        if (adminEmail != null) {

            Admin admin = adminRepository.findByEmail(adminEmail).orElse(null);

            if (admin != null) {
                model.addAttribute("admin", admin);
                model.addAttribute("userRole", "ADMIN");
            }
        }
    }
}
