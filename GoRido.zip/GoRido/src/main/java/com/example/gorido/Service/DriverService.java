package com.example.gorido.Service;
import com.example.gorido.DTO.DriverRegisterRequest;
import jakarta.servlet.http.HttpSession;
import org.springframework.ui.Model;

public interface DriverService {
    String loadUser(HttpSession session);
    String getAllDistricts();
    String registerDriver(DriverRegisterRequest request);
    String driverProfile(Model model, HttpSession session);
    String deleteDriver(HttpSession session);
}
