function payHire(id) {
    window.location.href = "/payment/ui?id=" + id;
}