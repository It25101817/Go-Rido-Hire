function viewRoute(btn) {
  var hireId = btn.getAttribute("data-id");
  window.location.href = "/viewRoute?hireId=" + hireId;

}

function endHire(btn) {

    var hireId = btn.getAttribute("data-hire-id");

    var form = new FormData();
    form.append("hireId", hireId);

    var request = new XMLHttpRequest();

    request.onreadystatechange = function () {

        if (request.readyState == 4 && request.status == 200) {

            var response = request.responseText;

            if (response !== "success") {
                alert(response);
            } else {
                location.reload();
            }
        }
    };

    request.open("POST", "/endHire", true);
    request.send(form);
}